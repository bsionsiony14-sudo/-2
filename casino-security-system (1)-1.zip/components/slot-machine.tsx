'use client'

import { useCallback, useRef, useState } from 'react'
import { Reel } from './reel'
import { SpinButton } from './spin-button'
import { generateSpin, type SpinOutcome } from '@/lib/spin-logic'
import { SYMBOLS } from '@/lib/symbols'
import { soundManager } from '@/lib/sound-manager'

type SlotMachineProps = {
  onResult: (outcome: SpinOutcome) => void
  onSpinStart: () => void
}

// Each reel stops one after another for a realistic cascade.
const REEL_DURATIONS = [1500, 2000, 2500]

export function SlotMachine({ onResult, onSpinStart }: SlotMachineProps) {
  const [targets, setTargets] = useState<string[]>([
    SYMBOLS[0].id,
    SYMBOLS[1].id,
    SYMBOLS[2].id,
  ])
  const [spinKey, setSpinKey] = useState(0)
  const [spinning, setSpinning] = useState<boolean[]>([false, false, false])
  const [highlight, setHighlight] = useState<'jackpot' | 'normal' | null>(null)
  const spinCountRef = useRef(0)
  const isBusy = spinning.some(Boolean)

  const handleSpin = useCallback(() => {
    if (isBusy) return

    // Determine outcome based on this user's spin number (1-based).
    spinCountRef.current += 1
    const result = generateSpin(spinCountRef.current)

    soundManager.play('spin')
    onSpinStart()
    setHighlight(null)
    setTargets(result.symbols)
    setSpinning([true, true, true])
    setSpinKey((k) => k + 1)

    // Reels land one by one.
    REEL_DURATIONS.forEach((d, i) => {
      setTimeout(() => {
        setSpinning((prev) => {
          const next = [...prev]
          next[i] = false
          return next
        })
      }, d)
    })

    // After the last reel lands, resolve the result + effects.
    setTimeout(() => {
      if (result.outcome === 'JACKPOT') {
        setHighlight('jackpot')
        soundManager.play('jackpot')
      } else if (result.outcome === 'NORMAL') {
        setHighlight('normal')
        soundManager.play('normal')
      } else {
        setHighlight(null)
        soundManager.play('lose')
      }
      onResult(result.outcome)
    }, REEL_DURATIONS[REEL_DURATIONS.length - 1] + 120)
  }, [isBusy, onResult, onSpinStart])

  return (
    <div className="flex w-full flex-col items-center gap-8">
      {/* Reel cabinet */}
      <div
        className={cnHighlightFrame(highlight)}
      >
        <div className="grid grid-cols-3 gap-3 sm:gap-4">
          {targets.map((id, i) => (
            <Reel
              key={i}
              spinKey={spinKey}
              targetId={id}
              spinning={spinning[i]}
              duration={REEL_DURATIONS[i]}
              highlight={!isBusy ? highlight : null}
            />
          ))}
        </div>
        {/* center payline */}
        <div className="pointer-events-none absolute inset-x-4 top-1/2 h-0.5 -translate-y-1/2 bg-gradient-to-r from-transparent via-accent/70 to-transparent" />
      </div>

      <SpinButton onSpin={handleSpin} disabled={isBusy} />
    </div>
  )
}

function cnHighlightFrame(highlight: 'jackpot' | 'normal' | null) {
  const base =
    'relative w-full max-w-xl rounded-3xl border p-4 sm:p-6 glass transition-all duration-500'
  if (highlight === 'jackpot') return `${base} border-gold shadow-gold`
  if (highlight === 'normal') return `${base} border-primary shadow-neon`
  return `${base} border-white/10`
}
