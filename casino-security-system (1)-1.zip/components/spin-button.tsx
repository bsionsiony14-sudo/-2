'use client'

import { cn } from '@/lib/utils'

type SpinButtonProps = {
  onSpin: () => void
  disabled?: boolean
}

export function SpinButton({ onSpin, disabled }: SpinButtonProps) {
  return (
    <button
      type="button"
      onClick={onSpin}
      disabled={disabled}
      aria-label="Spin the slot machine"
      className={cn(
        'group relative mx-auto flex h-16 w-full max-w-xs items-center justify-center gap-3 rounded-full',
        'bg-gradient-to-b from-accent to-[oklch(0.68_0.14_70)] font-mono text-xl font-bold tracking-[0.25em] text-accent-foreground uppercase',
        'shadow-gold transition-all duration-150',
        'hover:brightness-110 active:translate-y-1 active:brightness-95',
        'disabled:cursor-not-allowed disabled:opacity-60 disabled:active:translate-y-0',
      )}
    >
      <span className="absolute inset-0 rounded-full ring-2 ring-white/30 ring-inset" />
      <span className="absolute inset-x-6 top-1.5 h-3 rounded-full bg-white/40 blur-sm" />
      <span className="relative z-10">{disabled ? 'SPINNING' : 'SPIN'}</span>
    </button>
  )
}
