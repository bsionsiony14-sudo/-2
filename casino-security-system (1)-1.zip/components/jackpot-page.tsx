'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { LogOut, Sparkles } from 'lucide-react'
import { SlotMachine } from './slot-machine'
import type { SpinOutcome } from '@/lib/spin-logic'
import { cn } from '@/lib/utils'

type JackpotPageProps = {
  onLogout: () => void
}

export function JackpotPage({ onLogout }: JackpotPageProps) {
  const [overlay, setOverlay] = useState<SpinOutcome | null>(null)
  const overlayTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const handleSpinStart = useCallback(() => {
    setOverlay(null)
    if (overlayTimer.current) clearTimeout(overlayTimer.current)
  }, [])

  const handleResult = useCallback((outcome: SpinOutcome) => {
    if (outcome === 'LOSE') {
      setOverlay('LOSE')
      overlayTimer.current = setTimeout(() => setOverlay(null), 1400)
      return
    }
    setOverlay(outcome)
    overlayTimer.current = setTimeout(
      () => setOverlay(null),
      outcome === 'JACKPOT' ? 4200 : 2000,
    )
  }, [])

  useEffect(() => {
    return () => {
      if (overlayTimer.current) clearTimeout(overlayTimer.current)
    }
  }, [])

  return (
    <main className="relative flex min-h-dvh flex-col overflow-hidden">
      {/* Header */}
      <header className="relative z-30 flex items-center justify-between px-4 py-4 sm:px-8">
        <div className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-xl bg-accent/15 text-accent shadow-gold">
            <Sparkles className="size-5" />
          </span>
          <div className="leading-tight">
            <p className="font-mono text-sm font-bold tracking-[0.3em] text-accent uppercase text-glow-gold">
              LUXE VAULT
            </p>
            <p className="text-xs text-muted-foreground">Jackpot Terminal</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="flex items-center gap-2 rounded-full border border-white/10 glass px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-white/25 hover:text-accent"
        >
          <LogOut className="size-4" />
          <span className="hidden sm:inline">Logout</span>
        </button>
      </header>

      {/* Slot machine */}
      <div className="relative z-20 flex flex-1 flex-col items-center justify-center gap-8 px-4 py-8">
        <h1 className="text-center font-mono text-2xl font-bold tracking-[0.2em] text-foreground uppercase sm:text-3xl">
          <span className="text-glow-neon text-primary">SLOT</span>{' '}
          <span className="text-glow-gold text-accent">MACHINE</span>
        </h1>
        <SlotMachine onResult={handleResult} onSpinStart={handleSpinStart} />
      </div>

      {/* Win / lose overlays */}
      {overlay === 'JACKPOT' && <JackpotOverlay />}
      {overlay === 'NORMAL' && <NormalOverlay />}
      {overlay === 'LOSE' && <LoseOverlay />}
    </main>
  )
}

function JackpotOverlay() {
  return (
    <div className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center">
      {/* Golden screen flash */}
      <div className="animate-golden-flash absolute inset-0 bg-[radial-gradient(circle_at_center,oklch(0.85_0.16_85/0.9),oklch(0.82_0.15_60/0.5)_50%,transparent_75%)]" />
      <Confetti />
      <Particles />
      <div className="animate-jackpot-pop relative z-10 select-none text-center">
        <p className="font-mono text-5xl font-black tracking-[0.15em] text-accent uppercase text-glow-gold sm:text-8xl">
          JACKPOT!
        </p>
        <p className="mt-4 font-mono text-lg tracking-[0.4em] text-accent-foreground/90 uppercase">
          ★ ★ ★ WINNER ★ ★ ★
        </p>
      </div>
    </div>
  )
}

function NormalOverlay() {
  return (
    <div className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,oklch(0.72_0.16_235/0.35),transparent_65%)]" />
      <div className="animate-jackpot-pop relative z-10 select-none rounded-2xl border border-primary/50 glass px-8 py-5 shadow-neon">
        <p className="font-mono text-3xl font-bold tracking-[0.2em] text-primary uppercase text-glow-neon sm:text-4xl">
          WIN!
        </p>
      </div>
    </div>
  )
}

function LoseOverlay() {
  return (
    <div className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center">
      <div className="animate-jackpot-pop rounded-2xl border border-white/10 glass px-8 py-4">
        <p className="font-mono text-2xl font-medium tracking-[0.2em] text-muted-foreground uppercase">
          TRY AGAIN
        </p>
      </div>
    </div>
  )
}

const CONFETTI_COLORS = [
  'oklch(0.82 0.15 85)',
  'oklch(0.72 0.16 235)',
  'oklch(0.9 0.05 90)',
  'oklch(0.85 0.18 55)',
]

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 90 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 0.8,
        duration: 2 + Math.random() * 2,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        size: 6 + Math.random() * 8,
        rotate: Math.random() * 360,
      })),
    [],
  )
  return (
    <div className="absolute inset-0 overflow-hidden">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute top-0 block rounded-[2px]"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 1.6,
            backgroundColor: p.color,
            transform: `rotate(${p.rotate}deg)`,
            animation: `confetti-fall ${p.duration}s linear ${p.delay}s forwards`,
          }}
        />
      ))}
    </div>
  )
}

function Particles() {
  const dots = useMemo(
    () =>
      Array.from({ length: 24 }).map((_, i) => ({
        id: i,
        left: 30 + Math.random() * 40,
        top: 40 + Math.random() * 30,
        delay: Math.random() * 1.5,
        size: 4 + Math.random() * 6,
      })),
    [],
  )
  return (
    <div className="absolute inset-0">
      {dots.map((d) => (
        <span
          key={d.id}
          className={cn('absolute block rounded-full bg-accent')}
          style={{
            left: `${d.left}%`,
            top: `${d.top}%`,
            width: d.size,
            height: d.size,
            boxShadow: '0 0 12px oklch(0.82 0.15 85 / 0.9)',
            animation: `float-up 1.8s ease-out ${d.delay}s infinite`,
          }}
        />
      ))}
    </div>
  )
}
