'use client'

import { useRef, useState, type KeyboardEvent } from 'react'
import { KeyRound, Lock, ArrowRight } from 'lucide-react'
import { soundManager } from '@/lib/sound-manager'
import type { Role } from '@/lib/auth'
import { resolveRole } from '@/lib/auth'
import { cn } from '@/lib/utils'

type LoginPageProps = {
  onAuthenticated: (role: Role) => void
}

export function LoginPage({ onAuthenticated }: LoginPageProps) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState(false)
  const [shake, setShake] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const submit = () => {
    // Unlock audio on the first user gesture.
    soundManager.unlock()
    soundManager.play('click')

    const role = resolveRole(password)
    if (role) {
      onAuthenticated(role)
      return
    }
    setError(true)
    setShake(true)
    setTimeout(() => setShake(false), 500)
    inputRef.current?.focus()
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    // Respect CJK IME composition before submitting on Enter.
    if (e.key !== 'Enter') return
    if (e.nativeEvent.isComposing || e.keyCode === 229) return
    submit()
  }

  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden px-4">
      {/* ambient glow orbs */}
      <div className="pointer-events-none absolute -left-24 top-1/4 size-72 rounded-full bg-primary/20 blur-[120px]" />
      <div className="pointer-events-none absolute -right-24 bottom-1/4 size-72 rounded-full bg-accent/20 blur-[120px]" />

      <section
        className={cn(
          'relative w-full max-w-md rounded-3xl border border-white/10 glass p-8 shadow-neon sm:p-10',
          shake && 'animate-shake',
        )}
      >
        <div className="flex flex-col items-center text-center">
          <span className="mb-5 grid size-16 place-items-center rounded-2xl bg-gradient-to-b from-accent/25 to-primary/20 text-accent shadow-gold">
            <Lock className="size-7" />
          </span>
          <h1 className="font-mono text-2xl font-bold tracking-[0.28em] text-foreground uppercase">
            <span className="text-glow-gold text-accent">LUXE</span>{' '}
            <span className="text-glow-neon text-primary">VAULT</span>
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Restricted access · enter your key to continue
          </p>
        </div>

        <div className="mt-8 space-y-4">
          <div
            className={cn(
              'group flex items-center gap-3 rounded-2xl border bg-black/30 px-4 py-3.5 transition-all',
              error ? 'border-destructive/60' : 'border-white/15 focus-within:border-primary',
            )}
          >
            <KeyRound
              className={cn('size-5', error ? 'text-destructive' : 'text-muted-foreground')}
            />
            <input
              ref={inputRef}
              type="password"
              value={password}
              autoFocus
              autoComplete="off"
              placeholder="PASSWORD"
              aria-label="Password"
              onChange={(e) => {
                setPassword(e.target.value)
                if (error) setError(false)
              }}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent font-mono tracking-[0.3em] text-foreground placeholder:text-muted-foreground/50 focus:outline-none"
            />
          </div>

          {error && (
            <p className="text-center font-mono text-xs tracking-widest text-destructive uppercase">
              Access denied · invalid key
            </p>
          )}

          <button
            type="button"
            onClick={submit}
            className={cn(
              'flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-primary to-[oklch(0.6_0.15_240)]',
              'py-3.5 font-mono text-sm font-bold tracking-[0.3em] text-primary-foreground uppercase',
              'shadow-neon transition-all hover:brightness-110 active:translate-y-px',
            )}
          >
            Enter
            <ArrowRight className="size-4" />
          </button>
        </div>

        <p className="mt-6 text-center font-mono text-[10px] tracking-[0.25em] text-muted-foreground/50 uppercase">
          Authorized personnel only
        </p>
      </section>
    </main>
  )
}
