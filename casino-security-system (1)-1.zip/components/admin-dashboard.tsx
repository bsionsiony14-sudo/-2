'use client'

import { useEffect, useState } from 'react'
import { Activity, LogOut, Monitor, ShieldCheck, Signal } from 'lucide-react'
import { LiveMonitor } from './live-monitor'

type AdminDashboardProps = {
  onLogout: () => void
}

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [now, setNow] = useState<Date | null>(null)

  useEffect(() => {
    setNow(new Date())
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const timeStr = now
    ? now.toLocaleTimeString('en-GB', { hour12: false })
    : '--:--:--'
  const dateStr = now
    ? now.toLocaleDateString('en-CA', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      })
    : '----/--/--'

  return (
    <main className="relative flex min-h-dvh flex-col">
      {/* Header / control bar */}
      <header className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-4 border-b border-white/10 glass px-4 py-3 sm:px-8">
        <div className="flex items-center gap-3">
          <span className="grid size-9 place-items-center rounded-xl bg-primary/15 text-primary shadow-neon">
            <ShieldCheck className="size-5" />
          </span>
          <div className="leading-tight">
            <p className="font-mono text-sm font-bold tracking-[0.3em] text-primary uppercase text-glow-neon">
              CONTROL ROOM
            </p>
            <p className="text-xs text-muted-foreground">Admin Surveillance · Read-only</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-lg border border-white/10 bg-black/30 px-3 py-1.5 font-mono text-primary sm:flex">
            <span className="text-lg font-bold tabular-nums tracking-widest">{timeStr}</span>
            <span className="text-xs text-muted-foreground">{dateStr}</span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-2 rounded-full border border-white/10 glass px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-destructive/40 hover:text-destructive"
          >
            <LogOut className="size-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Status strip */}
      <section className="grid grid-cols-2 gap-3 px-4 py-4 sm:grid-cols-4 sm:px-8">
        <StatCard icon={<Signal className="size-4" />} label="Signal" value="STABLE" tone="primary" />
        <StatCard icon={<Activity className="size-4" />} label="Latency" value="-- ms" tone="muted" />
        <StatCard icon={<Monitor className="size-4" />} label="Feeds" value="1 / 1" tone="primary" />
        <StatCard icon={<ShieldCheck className="size-4" />} label="Access" value="ADMIN" tone="gold" />
      </section>

      {/* Monitor grid */}
      <section className="grid flex-1 gap-6 px-4 pb-8 sm:px-8 lg:grid-cols-[2fr_1fr]">
        {/* Primary CCTV feed */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-mono text-sm tracking-[0.25em] text-foreground uppercase">
              Primary Feed — Jackpot User
            </h2>
            <span className="font-mono text-xs tracking-widest text-muted-foreground">
              CH-01
            </span>
          </div>
          <LiveMonitor label="CAM 01" channel="JACKPOT-USER" />
          <p className="font-mono text-[11px] leading-relaxed tracking-wide text-muted-foreground">
            Placeholder monitor. Ready for Node.js + Socket.io + WebRTC live screen
            sharing from the active JACKPOT terminal.
          </p>
        </div>

        {/* Secondary panel */}
        <aside className="flex flex-col gap-4">
          <div className="rounded-2xl border border-white/10 glass p-4">
            <h3 className="mb-3 font-mono text-xs tracking-[0.25em] text-muted-foreground uppercase">
              Session Log
            </h3>
            <ul className="space-y-2 font-mono text-xs text-muted-foreground">
              <LogRow time={timeStr} text="Admin session started" />
              <LogRow time={timeStr} text="Awaiting broadcaster handshake" />
              <LogRow time={timeStr} text="WebRTC channel idle" />
            </ul>
          </div>

          <div className="rounded-2xl border border-white/10 glass p-4">
            <h3 className="mb-3 font-mono text-xs tracking-[0.25em] text-muted-foreground uppercase">
              Integration Status
            </h3>
            <div className="space-y-2.5">
              <PipelineRow label="Express Server" ready={false} />
              <PipelineRow label="Socket.io Signaling" ready={false} />
              <PipelineRow label="WebRTC Peer" ready={false} />
            </div>
          </div>
        </aside>
      </section>
    </main>
  )
}

function StatCard({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode
  label: string
  value: string
  tone: 'primary' | 'gold' | 'muted'
}) {
  const toneClass =
    tone === 'gold'
      ? 'text-accent'
      : tone === 'primary'
        ? 'text-primary'
        : 'text-muted-foreground'
  return (
    <div className="flex items-center gap-3 rounded-xl border border-white/10 glass px-3 py-2.5">
      <span className={`grid size-8 place-items-center rounded-lg bg-white/5 ${toneClass}`}>
        {icon}
      </span>
      <div className="leading-tight">
        <p className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase">
          {label}
        </p>
        <p className={`font-mono text-sm font-bold tracking-wider ${toneClass}`}>{value}</p>
      </div>
    </div>
  )
}

function LogRow({ time, text }: { time: string; text: string }) {
  return (
    <li className="flex items-start gap-2">
      <span className="tabular-nums text-primary/70">{time}</span>
      <span className="text-muted-foreground/50">›</span>
      <span>{text}</span>
    </li>
  )
}

function PipelineRow({ label, ready }: { label: string; ready: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="font-mono text-xs text-foreground">{label}</span>
      <span
        className={`flex items-center gap-1.5 font-mono text-[10px] tracking-widest uppercase ${
          ready ? 'text-primary' : 'text-muted-foreground'
        }`}
      >
        <span
          className={`size-2 rounded-full ${
            ready ? 'bg-primary' : 'bg-muted-foreground/50'
          }`}
        />
        {ready ? 'Online' : 'Pending'}
      </span>
    </div>
  )
}
