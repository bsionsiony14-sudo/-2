'use client'

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { SYMBOLS, getSymbolById } from '@/lib/symbols'
import { cn } from '@/lib/utils'

type ReelProps = {
  /** Increments to trigger a new spin. */
  spinKey: number
  /** Symbol id this reel should land on. */
  targetId: string
  /** Whether this reel is currently spinning. */
  spinning: boolean
  /** How long (ms) the spin lasts before landing. */
  duration: number
  /** Extra highlight when the whole result is a win. */
  highlight?: 'jackpot' | 'normal' | null
}

const STRIP_REPEAT = 8 // number of random symbols before the final one

function buildStrip(targetId: string) {
  const strip: string[] = []
  for (let i = 0; i < STRIP_REPEAT; i++) {
    strip.push(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].id)
  }
  strip.push(targetId) // final landing symbol
  return strip
}

export function Reel({ spinKey, targetId, spinning, duration, highlight }: ReelProps) {
  const windowRef = useRef<HTMLDivElement>(null)
  const [cellHeight, setCellHeight] = useState(0)
  const [strip, setStrip] = useState<string[]>(() => [targetId])
  const [offset, setOffset] = useState(0)
  const [transition, setTransition] = useState('none')

  // Measure the square reel window so we can translate in exact pixels.
  useLayoutEffect(() => {
    const el = windowRef.current
    if (!el) return
    const measure = () => setCellHeight(el.clientHeight)
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // Run a spin whenever spinKey changes.
  useEffect(() => {
    if (spinKey === 0) return
    if (cellHeight === 0) return

    const newStrip = buildStrip(targetId)
    setStrip(newStrip)
    setTransition('none')
    setOffset(0)

    // Next frame: animate to the final symbol with smooth easing.
    const raf = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const finalIndex = newStrip.length - 1
        setTransition(`transform ${duration}ms cubic-bezier(0.16, 1, 0.3, 1)`)
        setOffset(-finalIndex * cellHeight)
      })
    })
    return () => cancelAnimationFrame(raf)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spinKey, cellHeight])

  const landed = getSymbolById(targetId)

  return (
    <div
      ref={windowRef}
      className={cn(
        'relative aspect-square w-full overflow-hidden rounded-2xl border transition-all duration-300',
        'glass',
        highlight === 'jackpot'
          ? 'border-gold shadow-gold'
          : highlight === 'normal'
            ? 'border-primary shadow-neon'
            : 'border-white/10',
      )}
    >
      {/* subtle vertical vignette */}
      <div className="pointer-events-none absolute inset-0 z-20 bg-gradient-to-b from-black/50 via-transparent to-black/50" />

      {/* spinning motion blur while active */}
      {spinning && (
        <div className="pointer-events-none absolute inset-0 z-10 bg-gradient-to-b from-transparent via-white/5 to-transparent" />
      )}

      <div
        className="absolute inset-0 flex flex-col will-change-transform"
        style={{ transform: `translateY(${offset}px)`, transition }}
      >
        {strip.map((id, i) => {
          const sym = getSymbolById(id)
          return (
            <div
              key={`${id}-${i}`}
              className="flex w-full shrink-0 items-center justify-center p-3"
              style={{ height: cellHeight || undefined }}
            >
              <div className="relative h-full w-full">
                <Image
                  src={sym.src || '/placeholder.svg'}
                  alt={sym.name}
                  fill
                  sizes="200px"
                  className="object-contain drop-shadow-[0_4px_18px_rgba(0,0,0,0.6)]"
                  priority={i === strip.length - 1}
                />
              </div>
            </div>
          )
        })}
      </div>

      {/* accessible landed value */}
      <span className="sr-only">{landed.name}</span>
    </div>
  )
}
