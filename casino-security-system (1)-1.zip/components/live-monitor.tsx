'use client'

import { useEffect, useRef } from 'react'
import { VideoOff, Wifi } from 'lucide-react'

type LiveMonitorProps = {
  label?: string
  channel?: string
}

/**
 * CCTV monitor placeholder for the JACKPOT user's live screen.
 *
 * FUTURE INTEGRATION (Node.js + Express + Socket.io + WebRTC):
 * - The JACKPOT page (broadcaster) captures its screen via
 *   navigator.mediaDevices.getDisplayMedia() and creates an RTCPeerConnection.
 * - Signaling (offer/answer/ICE candidates) is exchanged over a Socket.io server.
 * - This component (viewer) receives the remote MediaStream and attaches it to
 *   the <video> element referenced by `videoRef` below:
 *       peerConnection.ontrack = (e) => { videoRef.current.srcObject = e.streams[0] }
 * - Replace the "NO SIGNAL" placeholder with the live <video> once connected.
 */
export function LiveMonitor({ label = 'CAM 01', channel = 'JACKPOT-USER' }: LiveMonitorProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    // Placeholder: no stream yet. Wire up the WebRTC MediaStream here later.
    const el = videoRef.current
    return () => {
      if (el?.srcObject) {
        ;(el.srcObject as MediaStream).getTracks().forEach((t) => t.stop())
        el.srcObject = null
      }
    }
  }, [])

  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-2xl border border-white/10 bg-black">
      {/* live video (hidden until a stream is attached) */}
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full object-cover"
        autoPlay
        playsInline
        muted
      />

      {/* Placeholder "no signal" state */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[repeating-linear-gradient(0deg,oklch(0.2_0.02_265)_0px,oklch(0.16_0.02_265)_2px,oklch(0.13_0.02_265)_3px)]">
        <VideoOff className="size-10 text-muted-foreground/60" />
        <p className="font-mono text-sm tracking-[0.3em] text-muted-foreground uppercase">
          NO SIGNAL
        </p>
        <p className="max-w-xs text-center font-mono text-[10px] tracking-wider text-muted-foreground/60 uppercase">
          Awaiting WebRTC stream · {channel}
        </p>
      </div>

      {/* moving scanline */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-scanline absolute inset-x-0 h-16 bg-gradient-to-b from-transparent via-primary/10 to-transparent" />
      </div>

      {/* CRT vignette */}
      <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_120px_rgba(0,0,0,0.85)]" />

      {/* HUD overlays */}
      <div className="absolute left-3 top-3 flex items-center gap-2">
        <span className="flex items-center gap-1.5 rounded-md bg-destructive/20 px-2 py-1 backdrop-blur">
          <span className="animate-pulse-ring size-2 rounded-full bg-destructive" />
          <span className="font-mono text-[11px] font-bold tracking-widest text-destructive">
            LIVE
          </span>
        </span>
      </div>
      <div className="absolute right-3 top-3 flex items-center gap-1.5 rounded-md bg-black/40 px-2 py-1 font-mono text-[11px] tracking-widest text-primary backdrop-blur">
        <Wifi className="size-3" />
        {label}
      </div>
      <div className="absolute bottom-3 left-3 font-mono text-[11px] tracking-widest text-white/70">
        REC ●
      </div>
      <div className="absolute bottom-3 right-3 font-mono text-[11px] tracking-widest text-white/70">
        {channel}
      </div>
    </div>
  )
}
