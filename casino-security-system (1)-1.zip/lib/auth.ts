// Simple front-end access control for the two valid keys.
// Passwords are case-sensitive as specified: ADMIN and JACKPOT.

export type Role = 'ADMIN' | 'JACKPOT'

const VALID_PASSWORDS: Record<string, Role> = {
  ADMIN: 'ADMIN',
  JACKPOT: 'JACKPOT',
}

export function resolveRole(password: string): Role | null {
  return VALID_PASSWORDS[password.trim()] ?? null
}
