// Slot machine symbols.
// Product images are displayed as-is (no color/proportion/quality changes).
// To swap or add symbols later, just edit this array.

export type Symbol = {
  id: string
  name: string
  src: string
}

export const SYMBOLS: Symbol[] = [
  { id: 'maichew', name: '마이쮸', src: '/symbols/maichew.png' },
  { id: 'saekom', name: '새콤달콤', src: '/symbols/saekom.png' },
  { id: 'isyu', name: '아이셔', src: '/symbols/isyu.png' },
]

export function getSymbolById(id: string): Symbol {
  return SYMBOLS.find((s) => s.id === id) ?? SYMBOLS[0]
}
