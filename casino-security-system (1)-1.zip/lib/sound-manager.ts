// Centralized sound manager.
//
// Sounds are currently synthesized with the Web Audio API so the app works
// with no external assets. To use real audio files later, drop files into
// /public/sounds and set the matching entry in SOUND_FILES below, e.g.
//   spin: '/sounds/spin.mp3'
// When a file URL is present it takes priority over the synthesized fallback.

export type SoundName = 'spin' | 'jackpot' | 'normal' | 'lose' | 'click'

export const SOUND_FILES: Partial<Record<SoundName, string>> = {
  // spin: '/sounds/spin.mp3',
  // jackpot: '/sounds/jackpot.mp3',
  // normal: '/sounds/normal.mp3',
  // lose: '/sounds/lose.mp3',
  // click: '/sounds/click.mp3',
}

class SoundManager {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private activeNodes: AudioNode[] = []
  private activeAudioEl: HTMLAudioElement | null = null
  private fileCache = new Map<SoundName, HTMLAudioElement>()

  private ensureContext() {
    if (typeof window === 'undefined') return null
    if (!this.ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext
      this.ctx = new AC()
      this.master = this.ctx.createGain()
      this.master.gain.value = 0.5
      this.master.connect(this.ctx.destination)
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume()
    return this.ctx
  }

  // Call once from a user gesture (e.g. login click) to unlock audio.
  unlock() {
    this.ensureContext()
  }

  // Stop any currently playing sound before a new one begins.
  stopAll() {
    this.activeNodes.forEach((n) => {
      try {
        ;(n as OscillatorNode).stop?.()
        n.disconnect()
      } catch {
        /* noop */
      }
    })
    this.activeNodes = []
    if (this.activeAudioEl) {
      this.activeAudioEl.pause()
      this.activeAudioEl.currentTime = 0
      this.activeAudioEl = null
    }
  }

  play(name: SoundName) {
    if (typeof window === 'undefined') return
    this.stopAll()

    const fileUrl = SOUND_FILES[name]
    if (fileUrl) {
      let el = this.fileCache.get(name)
      if (!el) {
        el = new Audio(fileUrl)
        this.fileCache.set(name, el)
      }
      el.currentTime = 0
      this.activeAudioEl = el
      void el.play().catch(() => {})
      return
    }

    // Synthesized fallbacks
    switch (name) {
      case 'spin':
        this.synthSpin()
        break
      case 'jackpot':
        this.synthJackpot()
        break
      case 'normal':
        this.synthNormal()
        break
      case 'lose':
        this.synthLose()
        break
      case 'click':
        this.synthClick()
        break
    }
  }

  private track(node: AudioNode) {
    this.activeNodes.push(node)
  }

  private synthClick() {
    const ctx = this.ensureContext()
    if (!ctx || !this.master) return
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.type = 'square'
    osc.frequency.setValueAtTime(320, ctx.currentTime)
    gain.gain.setValueAtTime(0.18, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12)
    osc.connect(gain).connect(this.master)
    osc.start()
    osc.stop(ctx.currentTime + 0.13)
    this.track(osc)
  }

  // Mechanical reel-clatter loop for the ~2s spin.
  private synthSpin() {
    const ctx = this.ensureContext()
    if (!ctx || !this.master) return
    const duration = 2.4
    const tickEvery = 0.07
    for (let t = 0; t < duration; t += tickEvery) {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'triangle'
      const start = ctx.currentTime + t
      osc.frequency.setValueAtTime(180 + Math.random() * 90, start)
      gain.gain.setValueAtTime(0.0001, start)
      gain.gain.linearRampToValueAtTime(0.12, start + 0.005)
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.05)
      osc.connect(gain).connect(this.master)
      osc.start(start)
      osc.stop(start + 0.06)
      this.track(osc)
    }
  }

  private synthJackpot() {
    const ctx = this.ensureContext()
    if (!ctx || !this.master) return
    // Ascending triumphant arpeggios repeated.
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51]
    const base = ctx.currentTime
    for (let rep = 0; rep < 3; rep++) {
      notes.forEach((freq, i) => {
        const start = base + rep * 0.55 + i * 0.09
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = 'sawtooth'
        osc.frequency.setValueAtTime(freq, start)
        gain.gain.setValueAtTime(0.0001, start)
        gain.gain.linearRampToValueAtTime(0.2, start + 0.02)
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.4)
        osc.connect(gain).connect(this.master)
        osc.start(start)
        osc.stop(start + 0.42)
        this.track(osc)
      })
    }
  }

  private synthNormal() {
    const ctx = this.ensureContext()
    if (!ctx || !this.master) return
    const notes = [659.25, 987.77]
    notes.forEach((freq, i) => {
      const start = ctx.currentTime + i * 0.12
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'sine'
      osc.frequency.setValueAtTime(freq, start)
      gain.gain.setValueAtTime(0.0001, start)
      gain.gain.linearRampToValueAtTime(0.22, start + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35)
      osc.connect(gain).connect(this.master)
      osc.start(start)
      osc.stop(start + 0.37)
      this.track(osc)
    })
  }

  private synthLose() {
    const ctx = this.ensureContext()
    if (!ctx || !this.master) return
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.type = 'sawtooth'
    const start = ctx.currentTime
    osc.frequency.setValueAtTime(300, start)
    osc.frequency.exponentialRampToValueAtTime(110, start + 0.4)
    gain.gain.setValueAtTime(0.2, start)
    gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45)
    osc.connect(gain).connect(this.master)
    osc.start(start)
    osc.stop(start + 0.47)
    this.track(osc)
  }
}

export const soundManager = new SoundManager()
