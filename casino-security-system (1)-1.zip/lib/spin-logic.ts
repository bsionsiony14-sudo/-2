import { SYMBOLS, type Symbol } from './symbols'

export type SpinOutcome = 'JACKPOT' | 'NORMAL' | 'LOSE'

type Probabilities = {
  JACKPOT: number
  NORMAL: number
  LOSE: number
}

// spinCount here is the 1-based index of the spin being evaluated.
// First 3 spins use the "early" table, 4th spin onward uses the "late" table.
const EARLY: Probabilities = { JACKPOT: 3, NORMAL: 95, LOSE: 2 }
const LATE: Probabilities = { JACKPOT: 1, NORMAL: 40, LOSE: 59 }

export function getProbabilities(spinNumber: number): Probabilities {
  return spinNumber <= 3 ? EARLY : LATE
}

function pickOutcome(spinNumber: number): SpinOutcome {
  const p = getProbabilities(spinNumber)
  const roll = Math.random() * 100
  if (roll < p.JACKPOT) return 'JACKPOT'
  if (roll < p.JACKPOT + p.NORMAL) return 'NORMAL'
  return 'LOSE'
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// Produces a valid 3-symbol result matching the desired outcome.
function buildResult(outcome: SpinOutcome): string[] {
  const ids = SYMBOLS.map((s) => s.id)

  if (outcome === 'JACKPOT') {
    const s = ids[Math.floor(Math.random() * ids.length)]
    return [s, s, s]
  }

  if (outcome === 'NORMAL') {
    // exactly two identical + one different
    const shuffled = shuffle(ids)
    const pair = shuffled[0]
    const other = shuffled[1]
    const positions = shuffle([pair, pair, other])
    return positions
  }

  // LOSE: all three different (requires at least 3 distinct symbols)
  if (ids.length >= 3) {
    return shuffle(ids).slice(0, 3)
  }
  // Fallback when fewer than 3 symbols exist: degrade to NORMAL-like.
  return buildResult('NORMAL')
}

export type SpinResult = {
  outcome: SpinOutcome
  symbols: string[]
}

// spinNumber is 1-based (the count of this spin for the current user session).
export function generateSpin(spinNumber: number): SpinResult {
  const outcome = pickOutcome(spinNumber)
  return { outcome, symbols: buildResult(outcome) }
}

export function describeSymbols(ids: string[]): Symbol[] {
  return ids.map((id) => SYMBOLS.find((s) => s.id === id) ?? SYMBOLS[0])
}
