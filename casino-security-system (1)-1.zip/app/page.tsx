'use client'

import { useState } from 'react'
import { LoginPage } from '@/components/login-page'
import { AdminDashboard } from '@/components/admin-dashboard'
import { JackpotPage } from '@/components/jackpot-page'
import { soundManager } from '@/lib/sound-manager'
import type { Role } from '@/lib/auth'

export default function Home() {
  // Session lives only in memory, so a refresh resets state (and the spin
  // counter inside the JackpotPage) exactly as required.
  const [role, setRole] = useState<Role | null>(null)

  const handleLogout = () => {
    soundManager.stopAll()
    setRole(null)
  }

  if (role === 'ADMIN') {
    return <AdminDashboard onLogout={handleLogout} />
  }

  if (role === 'JACKPOT') {
    return <JackpotPage onLogout={handleLogout} />
  }

  return <LoginPage onAuthenticated={setRole} />
}
